local positionx = 1300
local positiony = 0
local user_id = 0

local foundMatch = false
local inSpectatorAdminMode = false

local players = {}

local globalAdminLevel = 0

RMenu.Add('adminmenu', 'main', RageUI.CreateMenu("Admin Menu", "~y~Admin Player Interaction Menu", positionx, positiony, "stream", "adminmenu"))
RMenu.Add("adminmenu", "submenu", RageUI.CreateSubMenu(RMenu:Get("adminmenu", "main", positionx, positiony, "stream", "adminmenu")))
RMenu.Add("adminmenu", "searchname", RageUI.CreateSubMenu(RMenu:Get("adminmenu", "main", positionx, positiony, "stream", "adminmenu")))
RMenu.Add("adminmenu", "searchtempid", RageUI.CreateSubMenu(RMenu:Get("adminmenu", "main", positionx, positiony, "stream", "adminmenu")))
RMenu.Add("adminmenu", "searchpermid", RageUI.CreateSubMenu(RMenu:Get("adminmenu", "main", positionx, positiony, "stream", "adminmenu")))
RMenu:Get('adminmenu', 'main')

RageUI.CreateWhile(1.0,RMenu:Get("adminmenu", "main"),nil,function()
    RageUI.IsVisible(RMenu:Get("adminmenu", "main"),true, false,true,function()

        foundMatch = false

        RageUI.Button("Search by Name", "", {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
        end, RMenu:Get('adminmenu', 'searchname'))
        
        RageUI.Button("Search by Perm ID", "", {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
        end, RMenu:Get('adminmenu', 'searchpermid'))

        RageUI.Button("Search by Temp ID", "", {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
        end, RMenu:Get('adminmenu', 'searchtempid'))

        RageUI.Button("Teleport to Waypoint", "", {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if (Selected) then
                local WaypointHandle = GetFirstBlipInfoId(8)
                if DoesBlipExist(WaypointHandle) then
                  local waypointCoords = GetBlipInfoIdCoord(WaypointHandle)
                  for height = 1, 1000 do
                    SetPedCoordsKeepVehicle(PlayerPedId(), waypointCoords["x"], waypointCoords["y"], height + 0.0)
                    local foundGround, zPos = GetGroundZFor_3dCoord(waypointCoords["x"], waypointCoords["y"], height + 0.0)
                    if foundGround then
                        SetPedCoordsKeepVehicle(PlayerPedId(), waypointCoords["x"], waypointCoords["y"], height + 0.0)
                        break
                    end
                    Citizen.Wait(5)
                  end
                end
            end
        end, RMenu:Get('adminmenu', 'main'))
        
        RageUI.Button("Spawn BMX", "", {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if (Selected) then
                SpawnVehicle('bmx')
            end
        end, RMenu:Get('adminmenu', 'main'))

        for k,v in pairs(players) do

            RageUI.Button("[" .. v[3] .. "] " .. v[1], "Name: " .. v[1] .. " Perm ID: " .. v[3] .. " Temp ID: " .. v[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    SelectedPlayer = players[k]
                end
            end, RMenu:Get('adminmenu', 'submenu'))

        end
    end)
end)

RageUI.CreateWhile(1.0,RMenu:Get("adminmenu", "searchpermid"),nil,function()
    RageUI.IsVisible(RMenu:Get("adminmenu", "searchpermid"),true, false,true,function()

        if foundMatch == false then
            searchforPermID = KeyboardInput("Enter Perm ID", "", 10)
        end

            for k, v in pairs(players) do
                foundMatch = true
                if string.find(v[3],searchforPermID) then
                    RageUI.Button("[" .. v[3] .. "] " .. v[1], "Name: " .. v[1] .. " Perm ID: " .. v[3] .. " Temp ID: " .. v[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            SelectedPlayer = players[k]
                        end
                    end, RMenu:Get('adminmenu', 'submenu'))
                end
             end
        end)
    end)

    RageUI.CreateWhile(1.0,RMenu:Get("adminmenu", "searchtempid"),nil,function()
        RageUI.IsVisible(RMenu:Get("adminmenu", "searchtempid"),true, false,true,function()

            if foundMatch == false then
                searchid = KeyboardInput("Enter Temp ID", "", 10)
            end
    
                for k, v in pairs(players) do
                    foundMatch = true
                    if string.find(v[2], searchid) then
                        RageUI.Button("[" .. v[3] .. "] " .. v[1], "Name: " .. v[1] .. " Perm ID: " .. v[3] .. " Temp ID: " .. v[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
                            if Selected then
                                SelectedPlayer = players[k]
                            end
                        end, RMenu:Get('adminmenu', 'submenu'))
                    end
                 end
            end)
        end)

RageUI.CreateWhile(1.0,RMenu:Get("adminmenu", "searchname"),nil,function()
    RageUI.IsVisible(RMenu:Get("adminmenu", "searchname"),true, false,true,function()

        if foundMatch == false then
            SearchName = KeyboardInput("Enter Name", "", 10)
        end

            for k, v in pairs(players) do
                foundMatch = true
                if string.match(v[1],SearchName) then
                    RageUI.Button("[" .. v[3] .. "] " .. v[1], "Name: " .. v[1] .. " Perm ID: " .. v[3] .. " Temp ID: " .. v[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
                        if Selected then
                            SelectedPlayer = players[k]
                        end
                    end, RMenu:Get('adminmenu', 'submenu'))
                end
             end
        end)
    end)

RageUI.CreateWhile(1.0,RMenu:Get("adminmenu", "submenu"),nil,function()
    RageUI.IsVisible(RMenu:Get("adminmenu", "submenu"),true, false,true,function()

        if globalAdminLevel >= cfg.Ban then
            RageUI.Button("Ban", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
                if Selected then
                    local uid = GetPlayerServerId(PlayerId())
                    local banReason = KeyboardInput("Reason:", "", 100)
                    local banTime = KeyboardInput("Hours:", "", 20)
                    TriggerServerEvent('VRP:BanPlayer', uid, SelectedPlayer[3], banReason, tonumber(banTime))
                end
            end, RMenu:Get('adminmenu', 'submenu'))
        end
        
    if globalAdminLevel >= cfg.Kick then
        RageUI.Button("Kick", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local kickReason = KeyboardInput("Reason:", "", 100)
                local uid = GetPlayerServerId(PlayerId())
                TriggerServerEvent('VRP:KickPlayer', uid, SelectedPlayer[3], kickReason)
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.Freeze then
        RageUI.Button("Freeze", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local uid = GetPlayerServerId(PlayerId())
                isFrozen = not isFrozen
                TriggerServerEvent('VRP:FreezeSV', uid, SelectedPlayer[2], isFrozen)
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.Slap then
        RageUI.Button("Slap", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local uid = GetPlayerServerId(PlayerId())
                TriggerServerEvent('VRP:SlapPlayer', uid, SelectedPlayer[2])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.Revive then
        RageUI.Button("Revive", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local uid = GetPlayerServerId(PlayerId())
                TriggerServerEvent('VRP:RevivePlayer', uid, SelectedPlayer[2])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.TeleportToPlayer then
        RageUI.Button("Teleport to Player", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local newSource = GetPlayerServerId(PlayerId())
                TriggerServerEvent('VRP:TeleportToPlayer', newSource, SelectedPlayer[2])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.TeleportToMe then
        RageUI.Button("Teleport To Me", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local newSource = GetPlayerServerId(PlayerId())
                TriggerServerEvent('VRP:TeleportToMe', newSource, SelectedPlayer[2])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.Spectate then
        RageUI.Button("Spectate", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                TriggerServerEvent('VRP:SpectateCheck', SelectedPlayer[2])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.ShowF10 then
        RageUI.Button("Show Warnings", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                ExecuteCommand("showwarnings " .. SelectedPlayer[3])
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    if globalAdminLevel >= cfg.Warn then
        RageUI.Button("Warn", "Name: " .. SelectedPlayer[1] .. " Perm ID: " .. SelectedPlayer[3] .. " Temp ID: " .. SelectedPlayer[2], {RightLabel = "→→→"}, true, function(Hovered, Active, Selected)
            if Selected then
                local userIDtoWarn = getWarningUserID()
                local userWarningMessage = getWarningUserMsg()
    
                TriggerServerEvent("trp:warnPlayer",tonumber(userIDtoWarn),GetPlayerName(PlayerId()),userWarningMessage)
            end
        end, RMenu:Get('adminmenu', 'submenu'))
    end

    end)
end)

RegisterNetEvent('VRP:SlapPlayer')
AddEventHandler('VRP:SlapPlayer', function()
    SetEntityHealth(PlayerPedId(), 0)
end)

RegisterNetEvent('VRP:RevivePlayer')
AddEventHandler('VRP:RevivePlayer', function()
    SetEntityHealth(PlayerPedId(), 200)
end)

RegisterNetEvent('VRP:Freeze')
AddEventHandler('VRP:Freeze', function(isForzen)
    FreezeEntityPosition(PlayerPedId(), isForzen)
end)

RegisterNetEvent('VRP:Teleport')
AddEventHandler('VRP:Teleport', function(coords)
    print(coords)
    SetEntityCoords(PlayerPedId(), coords)
end)

RegisterNetEvent('VRP:Teleport2Me')
AddEventHandler('VRP:Teleport2Me', function(target2)
    local coords = GetEntityCoords(GetPlayerPed(GetPlayerFromServerId(target2)))
    SetEntityCoords(PlayerPedId(), coords)
end)


RegisterNetEvent("VRP:SendPlayerData")
AddEventHandler("VRP:SendPlayerData",function(players_table, adminlevel)
    globalAdminLevel = adminlevel
    players = players_table
    RageUI.Visible(RMenu:Get('adminmenu', 'main'), not RageUI.Visible(RMenu:Get('adminmenu', 'main')))
end)

local InSpectatorMode	= false
local TargetSpectate	= nil
local LastPosition		= nil
local polarAngleDeg		= 0;
local azimuthAngleDeg	= 90;
local radius			= -3.5;
local cam 				= nil
local PlayerDate		= {}
local ShowInfos			= false
local group

local function polar3DToWorld3D(entityPosition, radius, polarAngleDeg, azimuthAngleDeg)

    local polarAngleRad   = polarAngleDeg   * math.pi / 180.0
	local azimuthAngleRad = azimuthAngleDeg * math.pi / 180.0

	local pos = {
		x = entityPosition.x + radius * (math.sin(azimuthAngleRad) * math.cos(polarAngleRad)),
		y = entityPosition.y - radius * (math.sin(azimuthAngleRad) * math.sin(polarAngleRad)),
		z = entityPosition.z - radius * math.cos(azimuthAngleRad)
	}

	return pos
end


RegisterNetEvent('VRP:SpectateClient')
AddEventHandler('VRP:SpectateClient', function(target)
    TargetSpectate = target
    SpectatePlayer()
end)


function StopSpectatePlayer()
    InSpectatorMode = false
    TargetSpectate  = nil
    local playerPed = PlayerPedId()
    SetCamActive(cam,  false)
    DestroyCam(cam, true)
    RenderScriptCams(false, false, 0, true, true)
    SetEntityVisible(playerPed, true)
    SetEntityCollision(playerPed, true, true)
    FreezeEntityPosition(playePed, false)
    if savedCoords ~= vec3(0,0,1) then SetEntityCoords(PlayerPedId(), savedCoords) else SetEntityCoords(PlayerPedId(), 3537.363, 3721.82, 36.467) end
end

function SpectatePlayer()
    savedCoords = GetEntityCoords(PlayerPedId())
    SetEntityCoords(PlayerPedId(), Coords)
    InSpectatorMode = true
    local playerPed = PlayerPedId()
    SetEntityCollision(playerPed, false, false)
    SetEntityVisible(playerPed, false)
    FreezeEntityPosition(playePed, true)
    Citizen.CreateThread(function()

        if not DoesCamExist(cam) then
            cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
        end

        SetCamActive(cam, true)
        RenderScriptCams(true, false, 0, true, true)

    end, TargetSpectate)
    RequestCollisionAtCoord(NetworkGetPlayerCoords(GetPlayerFromServerId(tonumber(TargetSpectate))))
end

Citizen.CreateThread(function()
    while (true) do
        Wait(0)
        if InSpectatorMode then
            DrawHelpMsg("Press ~INPUT_CONTEXT~ to Stop Spectating")
            if IsControlJustPressed(1, 51) then
                StopSpectatePlayer()
            end
        end
    end
end)

Citizen.CreateThread(function()
    while (true) do
        Wait(0)
        if InSpectatorMode then
        
			local targetPlayerId = GetPlayerFromServerId(tonumber(TargetSpectate))
			local playerPed	  = GetPlayerPed(-1)
			local targetPed	  = GetPlayerPed(targetPlayerId)
            local coords	 =  NetworkGetPlayerCoords(GetPlayerFromServerId(tonumber(TargetSpectate)))
            
            Draw2DText(0.22, 0.90, 'Health: ~g~' .. GetEntityHealth(targetPed) .. " / " .. GetEntityMaxHealth(targetPed), 0.65) 
            Draw2DText(0.22, 0.86, 'Armor: ~b~' .. GetPedArmour(targetPed) .. " / " .. GetPlayerMaxArmour(targetPlayerId), 0.65)
			for i=0, 32, 1 do
				if i ~= PlayerId() then
					local otherPlayerPed = GetPlayerPed(i)
					SetEntityNoCollisionEntity(playerPed,  otherPlayerPed,  true)
					SetEntityVisible(playerPed, false)
				end
			end

			if IsControlPressed(2, 241) then
				radius = radius + 2.0;
			end

			if IsControlPressed(2, 242) then
				radius = radius - 2.0;
			end

			if radius > -1 then
				radius = -1
			end

			local xMagnitude = GetDisabledControlNormal(0, 1);
			local yMagnitude = GetDisabledControlNormal(0, 2);

			polarAngleDeg = polarAngleDeg + xMagnitude * 10;

			if polarAngleDeg >= 360 then
				polarAngleDeg = 0
			end

			azimuthAngleDeg = azimuthAngleDeg + yMagnitude * 10;

			if azimuthAngleDeg >= 360 then
				azimuthAngleDeg = 0;
			end

			local nextCamLocation = polar3DToWorld3D(coords, radius, polarAngleDeg, azimuthAngleDeg)

            SetCamCoord(cam,  nextCamLocation.x,  nextCamLocation.y,  nextCamLocation.z)
            PointCamAtEntity(cam,  targetPed)
			SetEntityCoords(playerPed, coords.x, coords.y, coords.z + 10)
        end
    end
end)

function Draw2DText(x, y, text, scale)
    SetTextFont(4)
    SetTextProportional(7)
    SetTextScale(scale, scale)
    SetTextColour(255, 255, 255, 255)
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextDropShadow()
    SetTextEdge(4, 0, 0, 0, 255)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x, y)
  end

RegisterNetEvent('VRP:Notify')
AddEventHandler('VRP:Notify', function(string)
    notify('~g~' .. string)
end)

Citizen.CreateThread(function() 
    while true do
        Citizen.Wait(0)
        local key = 38
        if IsControlJustPressed(1, cfg.Key) then
            TriggerServerEvent("VRP:GetPlayerData")
        end
    end
end)

function DrawHelpMsg(msg)
    SetTextComponentFormat("STRING")
    AddTextComponentString(msg)
    DisplayHelpTextFromStringLabel(0,0,1,-1)
end

function KeyboardInput(TextEntry, ExampleText, MaxStringLenght)
	AddTextEntry('FMMC_KEY_TIP1', TextEntry) 
	DisplayOnscreenKeyboard(1, "FMMC_KEY_TIP1", "", ExampleText, "", "", "", MaxStringLenght)
    blockinput = true 
    
	while UpdateOnscreenKeyboard() ~= 1 and UpdateOnscreenKeyboard() ~= 2 do 
		Citizen.Wait(0)
	end
		
	if UpdateOnscreenKeyboard() ~= 2 then
		local result = GetOnscreenKeyboardResult() 
		Citizen.Wait(500) 
		blockinput = false 
		return result 
	else
		Citizen.Wait(500)
		blockinput = false 
		return nil 
	end
end

function notify(string)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(string)
    DrawNotification(true, false)
end

function SpawnVehicle(VehicleName)
	local hash = GetHashKey(VehicleName)
	RequestModel(hash)
	local i = 0
	while not HasModelLoaded(hash) and i < 50 do
		Citizen.Wait(10)
		i = i + 1
	end
    if i >= 50 then
        return
	end
	local Ped = PlayerPedId()
	local Vehicle = CreateVehicle(hash, GetEntityCoords(Ped), GetEntityHeading(Ped), true, 0)
    i = 0
	while not DoesEntityExist(Vehicle) and i < 50 do
		Citizen.Wait(10)
		i = i + 1
	end
	if i >= 50 then
		return
	end
    SetPedIntoVehicle(Ped, Vehicle, -1)
    SetModelAsNoLongerNeeded(hash)
end

function getWarningUserID()
AddTextEntry('FMMC_MPM_NA', "Enter ID of the player you want to warn?")
DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Enter ID of the player you want to warn?", "1", "", "", "", 30)
while (UpdateOnscreenKeyboard() == 0) do
    DisableAllControlActions(0);
    Wait(0);
end
if (GetOnscreenKeyboardResult()) then
    local result = GetOnscreenKeyboardResult()
    if result then
        return result
    end
end
return false
end

function getWarningUserMsg()
AddTextEntry('FMMC_MPM_NA', "Enter warning message")
DisplayOnscreenKeyboard(1, "FMMC_MPM_NA", "Enter warning message", "", "", "", "", 30)
while (UpdateOnscreenKeyboard() == 0) do
    DisableAllControlActions(0);
    Wait(0);
end
if (GetOnscreenKeyboardResult()) then
    local result = GetOnscreenKeyboardResult()
    if result then
        return result
    end
end
return false
end