local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","AdminMenu")


local adminlevel = 0

RegisterServerEvent('VRP:GetPlayerData')
AddEventHandler('VRP:GetPlayerData', function()
    local user_id = vRP.getUserId({source})
    if vRP.hasGroup({user_id, "superadmin"}) then
        adminlevel = 3
    elseif vRP.hasGroup({user_id, "admin"}) then
        adminlevel = 2
    elseif vRP.hasGroup({user_id, "mod"}) then
        adminlevel = 1
    end

    if adminlevel > 0 then
        players = GetPlayers()
        players_table = {}
        for _,ActivePlayers in pairs(players) do
            name = GetPlayerName(ActivePlayers)
            user_id = vRP.getUserId({ActivePlayers})
            players_table[ActivePlayers] = {name, ActivePlayers, user_id}
        end
        TriggerClientEvent("VRP:SendPlayerData", source, players_table, adminlevel)
    end
end)


RegisterServerEvent('VRP:BanPlayer')
AddEventHandler('VRP:BanPlayer', function(admin, target, reason, duration)
    local target_id = vRP.getUserSource({target})
    local admin = vRP.getUserId({admin})
    if vRP.hasGroup({admin, "mod"}) then
        vRP.ban({target_id, reason or "No Reason Given"})
        TriggerEvent('VRP:BanPlayerLog', target, GetPlayerName(admin), reason, duration)
        TriggerClientEvent('VRP:Notify', admin, 'Banned Player')
    end
end)

RegisterServerEvent('VRP:KickPlayer')
AddEventHandler('VRP:KickPlayer', function(admin, target, reason)
    local target_id = vRP.getUserSource({target})
    local admin = vRP.getUserId({admin})
    if vRP.hasGroup({admin, "mod"}) then
        vRP.kick({target_id, reason or "No Reason Given"})
        TriggerEvent('VRP:KickPlayerLog', target, GetPlayerName(admin), reason)
        TriggerClientEvent('VRP:Notify', admin, 'Kicked Player')
    end
end)

RegisterServerEvent('VRP:SlapPlayer')
AddEventHandler('VRP:SlapPlayer', function(admin, target)
    local admin = vRP.getUserId({admin})
    if vRP.hasGroup({admin, "mod"}) then
        TriggerClientEvent('VRP:SlapPlayer', target)
        TriggerClientEvent('VRP:Notify', admin, 'Slapped Player')
    end
end)

RegisterServerEvent('VRP:RevivePlayer')
AddEventHandler('VRP:RevivePlayer', function(admin, target)
    local admin = vRP.getUserId({admin})
    if vRP.hasGroup({admin, "mod"}) then
        TriggerClientEvent('VRP:RevivePlayer', target)
	TriggerClientEvent('terrorRP:ClearDeathscreen', target)
        TriggerClientEvent('VRP:Notify', admin, 'Revived Player')
    end
end)

RegisterServerEvent('VRP:FreezeSV')
AddEventHandler('VRP:FreezeSV', function(admin, newtarget, isFrozen)
    local admin = vRP.getUserId({admin})
    if vRP.hasGroup({admin, "mod"}) then
        TriggerClientEvent('VRP:Freeze', newtarget, isFrozen)
        TriggerClientEvent('VRP:Notify', admin, 'Froze Player')
    end
end)

RegisterServerEvent('VRP:TeleportToPlayer')
AddEventHandler('VRP:TeleportToPlayer', function(source, newtarget)
    local coords = GetEntityCoords(GetPlayerPed(newtarget))
    local user_id = vRP.getUserId({source})
    if vRP.hasGroup({user_id, "mod"}) then
        TriggerClientEvent('VRP:Teleport', source, coords)
    end
end)

RegisterServerEvent('VRP:TeleportToMe')
AddEventHandler('VRP:TeleportToMe', function(source, newtarget)
    local user_id = vRP.getUserId({source})
    if vRP.hasGroup({user_id, "mod"}) then
        TriggerClientEvent('VRP:Teleport2Me', newtarget, source)
    end
end)

playersSpectating = {}
playersToSpectate = {}

RegisterServerEvent('VRP:SpectateCheck')
AddEventHandler('VRP:SpectateCheck', function(newtarget)
    local admin = source
    local user_id = vRP.getUserId({admin})
    if vRP.hasGroup({user_id, "mod"}) then
        TriggerClientEvent('VRP:SpectateClient', admin, newtarget)
    end
end)

RegisterServerEvent('VRP:Prompt')
AddEventHandler('VRP:Prompt', function(shit)
    local admin = source
    local user_id = vRP.getUserId({admin})
    vRP.prompt({source, "Clothing:", shit, function(player, PermID)
    end})
end)

