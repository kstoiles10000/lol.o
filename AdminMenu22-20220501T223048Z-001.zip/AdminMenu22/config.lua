-- 1 = Mod
-- 2 = Admin
-- 3 = Superadmin

cfg = {
    Key = 318, -- Key to open menu with
    Group = 1, -- Permission to open menu

    -- Diffrent Admin Permissions
    Ban = 2,
    Kick = 1,
    Freeze = 1,
    Slap = 2,
    Revive = 1,           
    TeleportToPlayer = 1,  
    TeleportToMe = 1,     
    Spectate = 2, 
    ShowF10 = 1, 
    Warn = 1,     
}